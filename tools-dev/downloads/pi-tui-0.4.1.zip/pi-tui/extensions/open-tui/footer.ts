import type { ExtensionContext, Theme, ThemeColor } from "@earendil-works/pi-coding-agent";
import { hostname as osHostname } from "node:os";
import { truncateToWidth, visibleWidth, wrapTextWithAnsi } from "@earendil-works/pi-tui";
import type { OpenTuiConfig } from "./config.ts";
import type { IconGlyphs } from "./icons.ts";
import { resolveGlyphs, resolveIconMode, runtimeSymbol } from "./icons.ts";
import type { GitStatus } from "./git.ts";
import type { RuntimeInfo } from "./runtime.ts";
import {
	alignRight,
	basenamePath,
	cacheHitColor,
	effortColor,
	fitSegmentsByPriority,
	fmtTokens,
	formatCwd,
	formatDuration,
	formatInputBreakdown,
	hasAnsiStyles,
	providerColor,
	sanitizeStatusPreservingStyles,
	stressColor,
	truncateBranch,
	truncatePath,
	type PrioritizedSegment,
} from "./utils.ts";
import type { FooterState, ModelMeta, UsageTotals } from "./state.ts";
import { getUsageTotals } from "./state.ts";
import { formatCredits, shortExpiry, shouldShowExpiry, type CostView } from "../wb-panel.ts";

export function shortHostname(hostname: string): string {
	return hostname.split(".")[0] ?? "";
}

function renderBar(theme: Theme, pct: number, barWidth: number, ascii: boolean): string {
	const filled = Math.max(0, Math.min(barWidth, Math.round((pct / 100) * barWidth)));
	const empty = barWidth - filled;
	const color = stressColor(pct);
	const filledCell = ascii ? "#" : "█";
	const emptyCell = ascii ? "-" : "░";
	return (
		theme.fg("dim", "[") +
		theme.fg(color, filledCell.repeat(filled)) +
		theme.fg("dim", emptyCell.repeat(empty)) +
		theme.fg("dim", "]")
	);
}

/** Compact context form: icon + percentage, no bar or token counts. */
function renderContextCompact(theme: Theme, ctx: ExtensionContext, glyphs: IconGlyphs): string {
	const contextUsage = ctx.getContextUsage();
	const contextWindow = contextUsage?.contextWindow ?? ctx.model?.contextWindow ?? 0;
	if (contextWindow <= 0) return "";
	const contextPct = contextUsage?.percent ?? 0;
	return `${theme.fg(stressColor(contextPct), glyphs.context)} ${theme.fg(stressColor(contextPct), `${contextPct.toFixed(1)}%`)}`;
}

function renderGitSegment(
	theme: Theme,
	git: GitStatus,
	glyphs: IconGlyphs,
	segments: OpenTuiConfig["footerSegments"],
	maxBranchLen = 20,
): string {
	const parts: string[] = [];
	if (segments.gitBranch) {
		if (git.branch) {
			parts.push(theme.fg("mdLink", glyphs.git));
			parts.push(theme.fg("mdLink", truncateBranch(git.branch, maxBranchLen)));
		} else if (git.commit?.detached) {
			parts.push(theme.fg("warning", glyphs.git));
			parts.push(theme.fg("warning", "HEAD"));
			if (git.commit.oid) {
				const shortHash = git.commit.oid.slice(0, 7);
				const tag = git.commit.tag ? ` ${git.commit.tag}` : "";
				parts.push(theme.fg("dim", `${shortHash}${tag}`));
			}
		}
	}

	if (segments.gitStatus) {
		const statusIcons: string[] = [];
		// ponytail: always show count — `!1` not `!`, so 1 vs 100 is distinguishable.
		const addStatus = (count: number, glyph: string, color: ThemeColor) => {
			if (count > 0) statusIcons.push(theme.fg(color, `${glyph}${count}`));
		};
		addStatus(git.conflicted, glyphs.conflicted, "error");
		addStatus(git.deleted, glyphs.deleted, "error");
		addStatus(git.modified, glyphs.modified, "warning");
		addStatus(git.renamed, glyphs.renamed, "warning");
		addStatus(git.staged, glyphs.staged, "success");
		addStatus(git.untracked, glyphs.untracked, "muted");
		addStatus(git.stashed, glyphs.stashed, "muted");

		if (git.ahead > 0 && git.behind > 0) {
			statusIcons.push(theme.fg("warning", `${glyphs.diverged}${git.ahead}/${git.behind}`));
		} else if (git.ahead > 0) {
			statusIcons.push(theme.fg("success", `${glyphs.ahead}${git.ahead}`));
		} else if (git.behind > 0) {
			statusIcons.push(theme.fg("warning", `${glyphs.behind}${git.behind}`));
		}

		const statusBlock = statusIcons.join(" ");
		if (statusBlock) {
			parts.push(`${theme.fg("dim", "[")}${statusBlock}${theme.fg("dim", "]")}`);
		}
	}

	return parts.join(" ");
}

function renderRuntimeSegment(
	theme: Theme,
	runtime: RuntimeInfo | null,
	iconMode: OpenTuiConfig["icons"]["mode"],
): string {
	if (!runtime) return "";
	const symbol = theme.fg("success", runtimeSymbol(runtime.name, iconMode));
	const version = runtime.version ? theme.fg("muted", runtime.version) : "";
	const label = [symbol, version].filter(Boolean).join(" ");
	return label;
}

function renderTimerSegment(theme: Theme, state: FooterState, glyphs: IconGlyphs): string {
	if (state.workingSince !== undefined) {
		return `${theme.fg("accent", glyphs.working)} ${theme.fg("dim", "working")} ${theme.fg("accent", formatDuration(Date.now() - state.workingSince))}`;
	}
	if (state.lastDoneIn !== undefined) {
		return `${theme.fg("success", glyphs.done)} ${theme.fg("success", "done")} ${theme.fg("text", formatDuration(state.lastDoneIn))}`;
	}
	return "";
}

function renderContextBar(
	theme: Theme,
	ctx: ExtensionContext,
	width: number,
	glyphs: IconGlyphs,
	iconMode: OpenTuiConfig["icons"]["mode"],
): string {
	const contextUsage = ctx.getContextUsage();
	const contextWindow = contextUsage?.contextWindow ?? ctx.model?.contextWindow ?? 0;
	const contextTokens = contextUsage?.tokens ?? 0;
	const contextPct = contextUsage?.percent ?? 0;

	// ponytail: render 0% bar once we know the window — keeps the right side
	// populated instead of collapsing everything left in an empty session.
	if (contextWindow <= 0) return "";

	const pctText = theme.fg(stressColor(contextPct), `${contextPct.toFixed(1)}%`);
	const ctxText = `${theme.fg("text", fmtTokens(contextTokens))}${theme.fg("dim", "/")}${theme.fg("text", fmtTokens(contextWindow))}`;
	const contextIcon = theme.fg(stressColor(contextPct), glyphs.context);
	// Cap the bar at `width - reserved` (with a floor of 4) so the full form
	// never forces the left segments out before compact/drop logic kicks in.
	const reserved = visibleWidth(contextIcon) + visibleWidth(pctText) + visibleWidth(ctxText) + 5 + 2;
	const barWidth = Math.max(4, Math.min(12, width - reserved));
	return `${contextIcon} ${renderBar(theme, contextPct, barWidth, resolveIconMode(iconMode) === "ascii")} ${pctText} ${theme.fg("dim", "·")} ${ctxText}`;
}

/**
 * 模型名里的上下文后缀（`· 1M` / `· 200K`）是 `models.json` 的静态文本，
 * 用 alt+m 调过窗口后它就不对了（用户 2026-10 报：设了 500k，这行永远写 1M）。
 * 所以把名字里那个尺寸段摘掉，换成 `ctx.model.contextWindow` 的**生效值**。
 */
function modelLabelWithLiveWindow(name: string, contextWindow: number | undefined): string {
	const parts = name.split(" · ").filter((part) => !/^\d+(?:\.\d+)?[KM]$/.test(part.trim()));
	const window = Number(contextWindow ?? 0);
	if (window > 0) parts.push(fmtTokens(window));
	return parts.join(" · ");
}

function renderStatsBlock(
	theme: Theme,
	totals: UsageTotals,
	cost: CostView,
	glyphs: IconGlyphs,
	segments: OpenTuiConfig["footerSegments"],
): string {
	const stats: string[] = [];
	if (segments.tokens) {
		stats.push(theme.fg("accent", `${glyphs.input} ${formatInputBreakdown(totals.input, totals.cacheRead)}`));
		stats.push(theme.fg("success", `${glyphs.output} ${fmtTokens(totals.output)}`));
		// ponytail: hide cache-hit rate when the provider never reported cache
		// tokens — avoids a misleading "0%" on providers without prompt caching.
		const hasCacheTokens = totals.cacheRead > 0 || totals.cacheWrite > 0;
		if (hasCacheTokens && totals.latestCacheHitRate !== undefined) {
			stats.push(theme.fg(cacheHitColor(totals.latestCacheHitRate), `${glyphs.cacheHit} ${totals.latestCacheHitRate.toFixed(1)}%`));
		}
	}
	if (segments.cost) {
		const costSegment = renderCostSegment(theme, totals, cost, glyphs);
		if (costSegment) stats.push(costSegment);
	}

	return stats.join(` ${theme.fg("dim", "|")} `);
}

/**
 * 费用段两种口径：
 * - `credits`（WorkBuddy 控制台网关）：余额 `⚡4568/7250`，快到期的批次追加 `⏳28@10-31`
 * - `usd`（普通 apikey）：pi 自己算的钱 `$0.123`，与以前完全一致
 * 取不到余额时标签标灰并加 `!!`，不把用户手里的数字换成 `—`。
 */
function renderCostSegment(theme: Theme, totals: UsageTotals, cost: CostView, glyphs: IconGlyphs): string {
	if (cost.mode === "credits") {
		const balance = cost.credits;
		if (!balance) return "";
		const stale = cost.stale === true;
		const valueColor = stale ? "muted" : "warning";
		const icon = theme.fg(valueColor, glyphs.credits);
		const remaining = theme.fg(valueColor, formatCredits(balance.remaining));
		const total = theme.fg("muted", `/${formatCredits(balance.total)}`);
		const flag = stale ? theme.fg("muted", `${glyphs.stale}${glyphs.stale}`) : "";
		let text = `${icon} ${remaining}${total}${flag}`;
		if (shouldShowExpiry(balance.expiryRemaining, balance.total, balance.expiryAt)) {
			const left = balance.expiryRemaining !== undefined && balance.expiryRemaining >= 1
				? formatCredits(balance.expiryRemaining)
				: "";
			const when = shortExpiry(balance.expiryAt as number);
			text += ` ${theme.fg("muted", `${glyphs.expiry}${left}@${when}`)}`;
		}
		return text;
	}
	return theme.fg("warning", `${glyphs.cost} $${totals.cost.toFixed(3)}`);
}

const ANSI_RESET = "\x1b[0m";

/**
 * Keep the colours an extension applied to its own status text. Plain text stays
 * muted so unstyled statuses keep the quiet footer look. The trailing reset
 * stops an unclosed style from tinting the separator and the next status.
 */
function renderStatusText(theme: Theme, status: string): string {
	if (!hasAnsiStyles(status)) return theme.fg("muted", status);
	return `${status}${ANSI_RESET}`;
}

function renderExtensionStatusLines(
	theme: Theme,
	extensionStatuses: ReadonlyMap<string, string>,
	glyphs: IconGlyphs,
	width: number,
): string[] {
	const statuses = Array.from(extensionStatuses.entries())
		.sort(([a], [b]) => a.localeCompare(b))
		.map(([, text]) => sanitizeStatusPreservingStyles(text))
		.filter((text) => text.length > 0);
	if (statuses.length === 0) return [];

	const separator = ` ${theme.fg("dim", "|")} `;
	const statusText = statuses.map((status) => renderStatusText(theme, status)).join(separator);
	const line = `${theme.fg("mdLink", glyphs.extensions)} ${statusText}`;
	return wrapTextWithAnsi(line, width);
}

export interface FooterHooks {
	setRequestRender: (fn: (() => void) | undefined) => void;
	scheduleGitRefresh: () => void;
}

interface FooterDataLike {
	getExtensionStatuses(): ReadonlyMap<string, string>;
}

export interface InlineFooterLine {
	left: string;
	right: string;
}

export interface InlineFooterLines {
	top: InlineFooterLine;
	bottom: InlineFooterLine;
}

/**
 * Split the bottom border content the way `alignRight` splits the plain row:
 * the right block (statistics) survives, the left one (model) shrinks to an
 * ellipsis and only then disappears. Keeps the assembled border inside its
 * budget so editor-side truncation never eats the right corner.
 */
function fitInlineLine(left: string, right: string, width: number, theme: Theme): InlineFooterLine {
	const rightWidth = visibleWidth(right);
	if (rightWidth > width) {
		return { left: "", right: truncateToWidth(right, width, theme.fg("dim", "...")) };
	}
	const availableForLeft = width - rightWidth - 1;
	if (availableForLeft <= 0) return { left: "", right };
	return { left: truncateToWidth(left, availableForLeft, theme.fg("dim", "...")), right };
}

export interface FooterHandle {
	renderInline(width: number): InlineFooterLines | undefined;
	cleanup(): void;
}

function fitInlineSegments(
	parts: readonly PrioritizedSegment[],
	width: number,
	theme: Theme,
): string {
	const separator = theme.fg("dim", " · ");
	const separatorReserve = Math.max(0, parts.length - 1) * Math.max(0, visibleWidth(separator) - 1);
	return fitSegmentsByPriority(
		parts,
		Math.max(0, width - separatorReserve),
		theme.fg("dim", "..."),
	).join(separator);
}

function renderFooterContent(
	ctx: ExtensionContext,
	getState: () => FooterState,
	getConfig: () => OpenTuiConfig,
	getModelMeta: () => ModelMeta,
	theme: Theme,
	footerData: FooterDataLike,
	width: number,
): { mainLines: [string, string]; inlineLines: InlineFooterLines; extensionLines: string[] } {
	if (width <= 0) {
		return {
			mainLines: ["", ""],
			inlineLines: {
				top: { left: "", right: "" },
				bottom: { left: "", right: "" },
			},
			extensionLines: [],
		};
	}

	const state = getState();
	const config = getConfig();
	const glyphs = resolveGlyphs(config.icons.mode);
	const segments = config.footerSegments;
	const meta = getModelMeta();
	const totals = getUsageTotals(ctx);

	const leftParts: PrioritizedSegment[] = [];
	const inlineTopLeftParts: PrioritizedSegment[] = [];
	const inlineTopRightParts: PrioritizedSegment[] = [];
	if (segments.cwd) {
		const maxCwd = Math.min(30, Math.max(10, Math.floor(width * 0.4)));
		const cwd = formatCwd(ctx.sessionManager.getCwd());
		const cwdPrefix = `${theme.fg("mdLink", glyphs.cwd)} `;
		const accent = (text: string) => theme.fg("accent", text);
		leftParts.push({
			text: `${cwdPrefix}${accent(truncatePath(cwd, maxCwd))}`,
			compactText: `${cwdPrefix}${accent(truncatePath(basenamePath(cwd), maxCwd))}`,
			priority: 0,
			truncate: (_text, maxWidth, ellipsis) => {
				const pathWidth = maxWidth - visibleWidth(cwdPrefix);
				if (pathWidth <= visibleWidth(ellipsis)) {
					return truncateToWidth(`${cwdPrefix}${accent(basenamePath(cwd))}`, maxWidth, ellipsis);
				}
				return `${cwdPrefix}${accent(truncatePath(basenamePath(cwd), pathWidth))}`;
			},
		});
		inlineTopRightParts.push(leftParts.at(-1)!);
	}
	if (segments.hostname) {
		const shortHost = shortHostname(osHostname());
		if (shortHost) {
			leftParts.push({
				text: `${theme.fg("dim", glyphs.host)} ${theme.fg("accent", shortHost)}`,
				priority: 1,
			});
			inlineTopRightParts.push(leftParts.at(-1)!);
		}
	}
	const sessionName = ctx.sessionManager.getSessionName();
	if (sessionName) {
		const sessionPart: PrioritizedSegment = {
			text: `${theme.fg("dim", glyphs.session)} ${theme.fg("text", truncateToWidth(sessionName, 24, theme.fg("dim", "...")))}`,
			priority: 2,
		};
		if (segments.sessionName) {
			leftParts.push(sessionPart);
			inlineTopLeftParts.push(sessionPart);
		}
	}
	const gitSeg = renderGitSegment(theme, state.git, glyphs, segments);
	if (gitSeg) {
		leftParts.push({ text: gitSeg, priority: 3 });
		inlineTopLeftParts.push(leftParts.at(-1)!);
	}
	if (segments.runtime) {
		const runtimeSeg = renderRuntimeSegment(theme, state.runtime, config.icons.mode);
		if (runtimeSeg) {
			leftParts.push({ text: runtimeSeg, priority: 4 });
			inlineTopRightParts.push(leftParts.at(-1)!);
		}
	}
	const timerSeg = renderTimerSegment(theme, state, glyphs);
	if (timerSeg) {
		leftParts.push({ text: timerSeg, priority: 1 });
		inlineTopRightParts.push(leftParts.at(-1)!);
	}

	// The context bar competes with the left segments for the same row:
	// full bar first, then the compact icon+pct form, then dropped.
	let contextText = "";
	let contextCompact: string | undefined;
	if (segments.context) {
		contextText = renderContextBar(theme, ctx, width, glyphs, config.icons.mode);
		const compact = renderContextCompact(theme, ctx, glyphs);
		if (compact && visibleWidth(compact) < visibleWidth(contextText)) {
			contextCompact = compact;
		}
	}
	const allParts: PrioritizedSegment[] = [...leftParts];
	if (contextText) {
		// ponytail: priority 4 = sheds with runtime, before git/timer/cwd.
		allParts.push({ text: contextText, compactText: contextCompact, priority: 4 });
		// Context stays at the far right; cwd is the first item in this group.
		inlineTopRightParts.push({ text: contextText, compactText: contextCompact, priority: 4 });
	}

	const fitted = fitSegmentsByPriority(allParts, width, theme.fg("dim", "..."));
	const fittedContext = contextText ? fitted.pop() ?? "" : "";
	const line1 = alignRight(fitted.join(" "), fittedContext, width, theme);

	const inlineLeftBudget = Math.floor(width * 0.45);
	const inlineTopLeft = fitInlineSegments(inlineTopLeftParts, inlineLeftBudget, theme);
	const inlineRightBudget = Math.max(0, width - visibleWidth(inlineTopLeft) - (inlineTopLeft ? 1 : 0));
	const inlineTop: InlineFooterLine = {
		left: inlineTopLeft,
		right: fitInlineSegments(inlineTopRightParts, inlineRightBudget, theme),
	};

	const modelParts: string[] = [];
	modelParts.push(theme.fg("mdLink", glyphs.model));
	if (meta.provider && meta.provider !== "Unknown") {
		modelParts.push(theme.fg(providerColor(ctx.model?.provider ?? "none"), meta.provider));
	}
	modelParts.push(theme.fg("text", modelLabelWithLiveWindow(meta.model, ctx.model?.contextWindow)));
	if (meta.effort && meta.effort !== "off") {
		modelParts.push(theme.fg(effortColor(meta.effort), `${glyphs.thinking} ${meta.effort}`));
	}
	// 本分支自有：提示模型选择器入口（内置 /model 无法被扩展覆盖，见 README）
	modelParts.push(theme.fg("dim", "alt+m 模型"));
	const modelBlock = modelParts.join(theme.fg("dim", " · "));
	const statsBlock = renderStatsBlock(theme, totals, state.cost, glyphs, segments);
	const inlineBottom = fitInlineLine(modelBlock, statsBlock, width, theme);
	const line2 = alignRight(inlineBottom.left, inlineBottom.right, width, theme);
	const mainLines: [string, string] = [line1, line2]
		.map((line) => truncateToWidth(line, width, theme.fg("dim", "..."))) as [string, string];
	const extensionLines = segments.extensionStatuses
		? renderExtensionStatusLines(theme, footerData.getExtensionStatuses(), glyphs, width)
		: [];
	return { mainLines, inlineLines: { top: inlineTop, bottom: inlineBottom }, extensionLines };
}

export function installFooter(
	ctx: ExtensionContext,
	getState: () => FooterState,
	getConfig: () => OpenTuiConfig,
	getModelMeta: () => ModelMeta,
	hooks: FooterHooks,
): FooterHandle {
	let renderInline: (width: number) => InlineFooterLines | undefined = () => undefined;

	ctx.ui.setFooter((tui, theme, footerData) => {
		hooks.setRequestRender(() => tui.requestRender());
		const unsubBranch = footerData.onBranchChange(() => {
			hooks.scheduleGitRefresh();
			tui.requestRender();
		});
		const getContent = (width: number) => renderFooterContent(
			ctx,
			getState,
			getConfig,
			getModelMeta,
			theme,
			footerData,
			width,
		);

		renderInline = (width) => getContent(width).inlineLines;

		return {
			dispose() {
				unsubBranch();
				hooks.setRequestRender(undefined);
				renderInline = () => undefined;
			},
			invalidate() {},
			render(width: number): string[] {
				if (width <= 0) return [""];
				const { mainLines, extensionLines } = getContent(width);
				return getConfig().inlineFooter ? extensionLines : [...mainLines, ...extensionLines];
			},
		};
	});

	return {
		renderInline: (width) => renderInline(width),
		cleanup() {
			ctx.ui.setFooter(undefined);
		},
	};
}
